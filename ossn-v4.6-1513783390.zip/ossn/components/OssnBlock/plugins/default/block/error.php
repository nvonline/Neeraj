<div class="row">
	<div class="col-md-11 ossn-page-contents ossn-blocked">
    		<i class="fa fa-ban"></i>
            <div><?php echo ossn_print('ossn:blocked:error');?></div>
            <p><?php echo ossn_print('ossn:blocked:error:note');?></p>
    </div>	
</div>