<footer>
    <div class="col-md-11">
        <div class="footer-contents">
            <div class="ossn-footer-menu">
                <?php echo ossn_view_menu('footer'); ?>
            </div>
            <?php echo ossn_fetch_extend_views('ossn/page/footer/contents'); ?>
        </div>
    </div>
</footer>
